# LoPRax Phoenix 3D Reference Pack

Purpose: source/reference assets for generating and validating the Phoenix 3D model and later particle system. These are not final production web assets.

## Files
- 00_master_concept.png — visual identity master
- 01_turnaround_sheet.png — overview/reference sheet
- 02_front_view.png — primary front reference
- 03_three_quarter_view.png — volume/depth reference
- 04_left_side_view.png — profile/anatomy reference
- 05_back_view.png — rear wing/back/tail reference
- 06_head_crest_detail.png — head, beak, eye, crown-like crest
- 07_wing_feather_detail.png — wing layering and rose cluster
- 08_tail_feather_detail.png — tail plume structure

## Recommended repository location
assets/source/phoenix/3d-reference/

Keep generated production files separately, for example:
assets/production/phoenix/3d/
assets/production/phoenix/textures/
assets/production/phoenix/particles/
